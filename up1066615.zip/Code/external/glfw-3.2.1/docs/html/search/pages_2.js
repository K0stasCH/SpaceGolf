var searchData=
[
  ['getting_20started',['Getting started',['../quick_guide.html',1,'']]]
];
